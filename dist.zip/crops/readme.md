# Crops Folder
This directory is where the finished images are saved.
